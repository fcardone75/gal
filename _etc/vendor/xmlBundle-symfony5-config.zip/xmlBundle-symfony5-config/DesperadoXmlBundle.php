<?php

/**
 * Xml Generator/Reader Bundle
 *
 * @author Desperado <desperado@minsk-info.ru>
 */

namespace Desperado\XmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * Xml Generator/Reader Bundle
 *
 * @author Desperado <desperado@minsk-info.ru>
 */
class DesperadoXmlBundle extends Bundle
{

}
